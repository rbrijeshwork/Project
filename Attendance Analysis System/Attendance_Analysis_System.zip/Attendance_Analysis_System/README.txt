Group No.06 Attendance Analysis System :
**************************************
Rathod Brijeshkumar Mukeshbhai (196310307126)
Prajapati Vishv Hareshbhai 	(196310307560)
Patel Jeel Mehendrakumar 	(196310307560)
******************************************************************************
Admin Features :			*	Faculty Features :		*
				*				*
Add/Modify Student			*	Add/Modify Student		*
Add/Modify Branch			*	Take Attendance of Class	*
Add/Modify Subject			*	Generate Record		*		
Add/Modify Class			*	Generate Report		*
Add/Modify Faculty			*				*
Assign Subject To Faculty		*				*
Take Attendance Of Any Faculty Class    	*				*
Generate Record			*				*
Generate Report			*				*
******************************************************************************
Admin Login : Email = admin
	      Password = admin123

Faculty Login : Email = rbrijesh306@gmail.com
	       Password = COMP_7126
	       Email = jeelpatel7085@gmail.com
	       Password = COMP_7085
	       Email = vishvprj7560@gmail.com
	       Password = COMP_7560
******************************************************************************
Contact Me : rbrijesh306@gmail.com