<?php 

$conn= new mysqli('localhost','root','','attendance_analysis_system')or die("Could not connect to mysql".mysqli_error($con));
