<?php
$dbHost = 'localhost';
$dbName = 'jobpro';
$dbUsername = 'root';
$dbPassword = '';
$dbc= mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName); 
?>
